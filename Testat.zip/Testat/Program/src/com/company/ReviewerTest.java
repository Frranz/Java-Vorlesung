package src.com.company;

import org.junit.Test;

import static org.junit.Assert.*;

public class ReviewerTest {

    @Test
    public void addReview() {

    }

    @Test
    public void getReviews() {
    }

    @Test
    public void getUserName() {
    }

    @Test
    public void getReviewByMovie() {
    }
}